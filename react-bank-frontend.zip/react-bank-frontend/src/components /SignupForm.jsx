import { useState } from 'react';
import axios from 'axios';

export default function SignupForm() {
  const [form, setForm] = useState({ username: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post('http://localhost:8080/api/signup', form);
    alert(res.data);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3 p-4 max-w-md mx-auto">
      <input className="w-full p-2 border" placeholder="Username" name="username" onChange={e => setForm({...form, username: e.target.value})} />
      <input className="w-full p-2 border" type="password" placeholder="Password" name="password" onChange={e => setForm({...form, password: e.target.value})} />
      <button className="bg-blue-600 text-white px-4 py-2 w-full">Signup</button>
    </form>
  );
}