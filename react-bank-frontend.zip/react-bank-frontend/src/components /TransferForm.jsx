import { useState } from 'react';
import axios from 'axios';

export default function TransferForm() {
  const [amount, setAmount] = useState('');

  const handleTransfer = async () => {
    await axios.post('http://localhost:8080/api/transfer', { amount });
    alert("Transferred successfully");
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <input className="w-full p-2 border" type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <button className="mt-2 bg-yellow-600 text-white px-4 py-2 w-full" onClick={handleTransfer}>Transfer</button>
    </div>
  );
}