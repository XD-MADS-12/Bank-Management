import { useState } from 'react';
import axios from 'axios';

export default function DepositForm() {
  const [amount, setAmount] = useState('');

  const handleDeposit = async () => {
    await axios.post('http://localhost:8080/api/deposit', { amount });
    alert("Deposited successfully");
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <input className="w-full p-2 border" type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <button className="mt-2 bg-purple-600 text-white px-4 py-2 w-full" onClick={handleDeposit}>Deposit</button>
    </div>
  );
}