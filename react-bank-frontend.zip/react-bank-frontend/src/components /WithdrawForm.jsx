import { useState } from 'react';
import axios from 'axios';

export default function WithdrawForm() {
  const [amount, setAmount] = useState('');

  const handleWithdraw = async () => {
    await axios.post('http://localhost:8080/api/withdraw', { amount });
    alert("Withdrawn successfully");
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <input className="w-full p-2 border" type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
      <button className="mt-2 bg-red-600 text-white px-4 py-2 w-full" onClick={handleWithdraw}>Withdraw</button>
    </div>
  );
}