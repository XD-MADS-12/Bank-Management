import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import SignupForm from "./components/SignupForm";
import LoginForm from "./components/LoginForm";
import DepositForm from "./components/DepositForm";
import WithdrawForm from "./components/WithdrawForm";
import TransferForm from "./components/TransferForm";

function App() {
  return (
    <div className="space-y-8">
      <SignupForm />
      <LoginForm />
      <DepositForm />
      <WithdrawForm />
      <TransferForm />
    </div>
  );
}

export default App;