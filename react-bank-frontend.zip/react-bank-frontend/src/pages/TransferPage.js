import React, { useState } from 'react';

const TransferPage = () => {
  const [oldAccount, setOldAccount] = useState('');
  const [newAccount, setNewAccount] = useState('');
  const [amount, setAmount] = useState('');

  const handleTransfer = () => {
    // TODO: Call backend to submit transfer & send EmailJS email
    alert(`Transfer request: ${amount} from ${oldAccount} to ${newAccount}`);
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Old to New Account Transfer</h2>
      <input className="border p-2 w-full mb-2" type="text" placeholder="Old Account Number" onChange={(e) => setOldAccount(e.target.value)} />
      <input className="border p-2 w-full mb-2" type="text" placeholder="New Account Number" onChange={(e) => setNewAccount(e.target.value)} />
      <input className="border p-2 w-full mb-2" type="number" placeholder="Amount" onChange={(e) => setAmount(e.target.value)} />
      <button className="bg-yellow-600 text-white px-4 py-2 rounded" onClick={handleTransfer}>Submit Transfer</button>
    </div>
  );
};

export default TransferPage;