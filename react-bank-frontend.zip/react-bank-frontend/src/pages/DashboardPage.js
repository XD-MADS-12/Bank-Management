import React from 'react';
import { Link } from 'react-router-dom';

const DashboardPage = () => {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Dashboard</h2>
      <p className="mb-4">Welcome back! Choose an action below.</p>
      <div className="space-x-4">
        <Link to="/deposit" className="bg-green-500 text-white px-4 py-2 rounded">Deposit</Link>
        <Link to="/transfer" className="bg-yellow-500 text-white px-4 py-2 rounded">Transfer</Link>
      </div>
    </div>
  );
};

export default DashboardPage;