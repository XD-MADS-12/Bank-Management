import React, { useState } from 'react';

const DepositPage = () => {
  const [amount, setAmount] = useState('');

  const handleDeposit = () => {
    // TODO: Call backend to process deposit
    alert(`Depositing: ${amount}`);
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Deposit</h2>
      <input className="border p-2 w-full mb-2" type="number" placeholder="Amount" onChange={(e) => setAmount(e.target.value)} />
      <button className="bg-green-600 text-white px-4 py-2 rounded" onClick={handleDeposit}>Deposit</button>
    </div>
  );
};

export default DepositPage;